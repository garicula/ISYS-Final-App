// Garrick Morley
// ISYS 221-001
// Final Exam Program
// Due: 12/12/2021

// Allows transfer of data between files
package com.example.finalexamfinalbuild;

// Imports the needed permissions
import static android.Manifest.permission.RECORD_AUDIO;
import static android.Manifest.permission.WRITE_EXTERNAL_STORAGE;

// Imports the audio manager system
import android.media.AudioManager;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.MediaPlayer;
import android.media.MediaRecorder;

// Imports the other necessary android and androidx imports
import android.os.Bundle;
import android.os.Environment;
import android.widget.Button;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

// Import all of the Java functions
import android.view.View;
import android.view.View.OnClickListener;
import java.io.File;
import java.io.IOException;


// Main class to run everything
public class MainActivity extends AppCompatActivity {

    // Initialize the buttons' nicknames
    private Button startbtn, stopbtn, playbtn, stopplay, broswerBtn;
    private AudioManager mManager;
    private MediaRecorder mRecorder;
    private MediaPlayer mPlayer;
    private static final String LOG_TAG = "AudioRecording";
    private static String mFileName = "myfile.3gp";
    public static final int REQUEST_AUDIO_PERMISSION_CODE = 1;

    // Function to create the initial visual state of the app
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Connects all of the buttons to their corresponding layout_main.xml page names
        startbtn = findViewById(R.id.btnRecord);
        stopbtn = findViewById(R.id.btnStop);
        playbtn = findViewById(R.id.btnPlay);
        stopplay = findViewById(R.id.btnStopPlay);
        broswerBtn = findViewById(R.id.btnBrowser);
        startbtn.setEnabled(true);
        stopbtn.setEnabled(true);
        playbtn.setEnabled(true);
        stopplay.setEnabled(true);
        broswerBtn.setEnabled(true);

        // Button at top left of UI, starts the recording
        startbtn.setOnClickListener(v -> {
            try {
                startRecording();
            } catch (Exception e) {
                e.printStackTrace();
            }
        });

        // Button at top right of UI, stops the recording
        stopbtn.setOnClickListener(v -> {
            try {
                stopRecording();
            } catch (Exception e) {
                e.printStackTrace();
            }
        });

        // Button at middle left of UI, plays back the recording
        playbtn.setOnClickListener(v -> {
            try {
                playRecording();
            } catch (Exception e) {
                e.printStackTrace();
            }
        });

        // Button at middle right of UI, pauses the playback of the recording
        stopplay.setOnClickListener(v -> {
            try {
                stopPlayRecording();
            } catch (Exception e) {
                e.printStackTrace();
            }
        });


        // File browser button at the bottom right of the UI, opens the file browser in app
        broswerBtn.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setAction(Intent.ACTION_GET_CONTENT);
                intent.setType("*/*");
                startActivity(intent);
            }
        });

    }


    // Function used to stop the recoding (used above)
    private void stopPlayRecording() {
        mPlayer.release();
        mPlayer = null;
        stopbtn.setEnabled(false);
        startbtn.setEnabled(true);
        playbtn.setEnabled(true);
        stopplay.setEnabled(false);
        Toast.makeText(getApplicationContext(), "Playing Audio Stopped", Toast.LENGTH_SHORT).show();
    }

    // Function used to play the recording (used above)
    private void playRecording() throws IOException {
        stopbtn.setEnabled(false);
        startbtn.setEnabled(true);
        playbtn.setEnabled(false);
        stopplay.setEnabled(true);
        mPlayer = new MediaPlayer();

        // Make sure SD card is available just like To Do List app
        String state = Environment.getExternalStorageState();
        if (Environment.MEDIA_MOUNTED.equals(state)) {
            File downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);

            // Create the directory if it doesn't exist
            if (!downloadsDir.exists()) {
                downloadsDir.mkdirs();
            }

            // Save list to Downloads directory
            File file = new File(downloadsDir, mFileName);

            mPlayer.setDataSource(String.valueOf(file));
            mPlayer.prepare();
            mPlayer.start();
            Toast.makeText(getApplicationContext(), "Recording Started Playing", Toast.LENGTH_LONG).show();
        }
    }

    // Function that stops the recording (used above)
    private void stopRecording() {
        stopbtn.setEnabled(false);
        startbtn.setEnabled(true);
        playbtn.setEnabled(true);
        stopplay.setEnabled(true);
        mRecorder.stop();
        mRecorder.release();
        mRecorder = null;
        Toast.makeText(getApplicationContext(), "Recording Stopped", Toast.LENGTH_LONG).show();
    }


    // Function used to start the recording (used above)
    private void startRecording() throws IOException {
        if (CheckPermissions()) {
            stopbtn.setEnabled(true);
            startbtn.setEnabled(false);
            playbtn.setEnabled(false);
            stopplay.setEnabled(false);
            mRecorder = new MediaRecorder();
            mRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
            mRecorder.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);
            mRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);

            //Make sure SD card is available
            String state = Environment.getExternalStorageState();
            if (Environment.MEDIA_MOUNTED.equals(state)) {
                File downloadsDir = Environment.getExternalStoragePublicDirectory(
                        Environment.DIRECTORY_DOWNLOADS);

                // Create the directory if it doesn't exist
                if (!downloadsDir.exists()) {
                    downloadsDir.mkdirs();
                }
                // Save list to Downloads directory
                File file = new File(downloadsDir, mFileName);

                mRecorder.setOutputFile(file);
                mRecorder.prepare();
                mRecorder.start();
                Toast.makeText(getApplicationContext(), "Recording Started", Toast.LENGTH_LONG).show();
            }
        } else {
            RequestPermissions();
        }
    }

    // Main function used to check for permissions
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_AUDIO_PERMISSION_CODE) {
            if (grantResults.length > 0) {
                boolean permissionToRecord = grantResults[0] == PackageManager.PERMISSION_GRANTED;
                boolean permissionToStore = grantResults[1] == PackageManager.PERMISSION_GRANTED;
                if (permissionToRecord && permissionToStore) {
                    Toast.makeText(getApplicationContext(), "Permission Granted", Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(getApplicationContext(), "Permission Denied", Toast.LENGTH_LONG).show();
                }
            }
        }
    }

    // Backup function to check for permissions
    public boolean CheckPermissions() {
        int result = ContextCompat.checkSelfPermission(getApplicationContext(), WRITE_EXTERNAL_STORAGE);
        int result1 = ContextCompat.checkSelfPermission(getApplicationContext(), RECORD_AUDIO);
        return result == PackageManager.PERMISSION_GRANTED && result1 == PackageManager.PERMISSION_GRANTED;
    }

    // One last check to make sure all the permissions went through correctly
    private void RequestPermissions() {
        ActivityCompat.requestPermissions(MainActivity.this, new String[]{RECORD_AUDIO, WRITE_EXTERNAL_STORAGE}, REQUEST_AUDIO_PERMISSION_CODE);
    }
}